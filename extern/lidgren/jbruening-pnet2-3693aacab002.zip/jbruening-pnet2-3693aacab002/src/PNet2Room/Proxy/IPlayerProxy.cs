﻿namespace PNetR
{
    public interface IPlayerProxy
    {
        Player Player { get; set; }
    }
}