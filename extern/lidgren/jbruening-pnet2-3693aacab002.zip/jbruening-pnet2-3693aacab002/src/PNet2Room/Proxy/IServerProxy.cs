﻿namespace PNetR
{
    public interface IServerProxy
    {
        Server Server { get; set; }
    }
}