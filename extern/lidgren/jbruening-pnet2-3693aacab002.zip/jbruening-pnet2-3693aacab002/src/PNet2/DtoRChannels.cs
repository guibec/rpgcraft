﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PNet
{
    internal class DtoRChannels
    {
        public const int PlayerSwitch = 10;
        public const int PlayerData = 9;
    }
}
