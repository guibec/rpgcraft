﻿namespace PNet
{
    public enum RoomAuthType
    {
        AllowedHost = 0,
        AllowedToken = 1,
    }
}
