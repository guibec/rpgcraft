﻿namespace PNetS
{
    public interface IPlayerProxy
    {
        Player Player { get; set; }
    }
}