﻿namespace PNetS
{
    public interface IRoomProxy
    {
        Room Room { get; set; }
    }
}