In order to read the documentation you may have to unblock it by doing this:

1. Right-click the .CHM file and choose Properties
2. On the General tab, click the button labeled "Unblock"
3. Click OK

For reference, see: http://support.microsoft.com/kb/2021383
